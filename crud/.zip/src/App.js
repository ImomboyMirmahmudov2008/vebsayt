import './App.css';
import CrudPage from './Components/CrudPage';

function App() {
  return (
    <div className="App">
        <CrudPage />
    </div>
  );
}

export default App;
